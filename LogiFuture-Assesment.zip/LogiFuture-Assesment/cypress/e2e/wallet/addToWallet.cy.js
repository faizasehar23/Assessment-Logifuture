import { getRandomInt } from "../../helpers/utils.cy.js";
describe('Deposit', ()=> {
    
    let authToken, userId, transactionId, transactionBody;
    
    before("LogIn", () => {
        cy.logInReq().then((login) => {
            authToken = login.token;
            userId = login.userId;
        })
    })

    it ('Get user details', () => {
        cy.getUserDetails(authToken, userId)
    })

    it('Get wallet details - Before transaction', ()=> {
        cy.getWalletDetails(authToken, true)
    })

    it('Deposit EUR', ()=> {
        const randomNum = getRandomInt(100, 200)
        transactionBody = {
            "currency": "EUR",
            "amount": randomNum,
            "type": "credit"
          }
        cy.makeTransaction(authToken, transactionBody, 200).then((transaction) => {
            transactionId = transaction
        })
        cy.getWalletDetails(authToken, true)
    })

    it('Deposit USD', ()=> {
        const randomNum = getRandomInt(100, 200)
        transactionBody = {
            "currency": "USD",
            "amount": randomNum,
            "type": "credit"
          }
        cy.makeTransaction(authToken, transactionBody, 200).then((transaction) => {
            transactionId = transaction
        })
    })

    it('Check last transaction', () => {
        cy.checkTransaction(authToken, transactionId, transactionBody, 3)
    })

    it('Check all transactions', ()=> {
        cy.getAllTransactions(authToken, transactionId, transactionBody)
    })

    it('Get wallet details - After transaction', ()=> {
        cy.getWalletDetails(authToken, false)
    })
})