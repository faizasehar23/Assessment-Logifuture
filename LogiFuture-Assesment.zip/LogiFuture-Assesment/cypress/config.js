export const credentials = {
    username: "testfaiza123",
    password: "testUser123@"
  };

export const xServiceID = 'test9NMA'
  
  